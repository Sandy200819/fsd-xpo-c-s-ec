﻿import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';
const { app } = await import('../server/index.js');

let server;
let baseUrl;

before(async () => {
  await new Promise((resolve) => {
    server = app.listen(0, () => {
      const { port } = server.address();
      baseUrl = `http://127.0.0.1:${port}`;
      resolve();
    });
  });
});

after(() => {
  server?.close();
});

describe('SkillSprout SQLite & REST API Integration', () => {
  it('GET /api/health confirms SQLite storage', async () => {
    const res = await fetch(`${baseUrl}/api/health`);
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.storage, 'SQLite');
  });

  it('POST /api/roadmap returns 400 on invalid experience input', async () => {
    const res = await fetch(`${baseUrl}/api/roadmap`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ career: 'Full-Stack Web', experience: 'InvalidLevel' }),
    });
    assert.equal(res.status, 400);
  });

  it('PUT and GET /api/plans/:studentId persists student data in SQLite', async () => {
    const saveRes = await fetch(`${baseUrl}/api/plans/test-roll-01`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Alex',
        branch: 'CSE',
        semester: '3',
        experience: 'Some basics',
        career: 'Full-Stack Web',
        hours: 14,
        enrolled: ['CS101', 'WD101'],
        completed: ['CS101'],
      }),
    });
    assert.equal(saveRes.status, 200);

    const getRes = await fetch(`${baseUrl}/api/plans/test-roll-01`);
    const plan = await getRes.json();
    assert.equal(getRes.status, 200);
    assert.equal(plan.name, 'Alex');
    assert.deepEqual(plan.enrolled, ['CS101', 'WD101']);
  });

  it('POST /api/audit returns readiness report and logs to SQLite', async () => {
    const res = await fetch(`${baseUrl}/api/audit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        studentId: 'test-roll-01',
        career: 'Full-Stack Web',
        hours: 14,
        enrolled: ['CS101', 'WD101'],
        completed: ['CS101'],
      }),
    });
    const report = await res.json();
    assert.equal(res.status, 200);
    assert.equal(typeof report.readinessScore, 'number');
    assert.ok(Array.isArray(report.findings));
  });
});
