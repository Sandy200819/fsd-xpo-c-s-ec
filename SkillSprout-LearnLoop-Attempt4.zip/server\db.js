﻿import { DatabaseSync } from 'node:sqlite';
import path from 'path';
import { fileURLToPath } from 'url';
import { courses as initialCourses, careerTracks as initialTracks } from './data.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, '../skillsprout.db');

export const db = new DatabaseSync(dbPath);

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS courses (
      code TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      credits INTEGER NOT NULL,
      prerequisites TEXT NOT NULL,
      level TEXT NOT NULL,
      tag TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS career_tracks (
      name TEXT PRIMARY KEY,
      course_codes TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS student_plans (
      student_id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      branch TEXT NOT NULL,
      semester TEXT NOT NULL,
      experience TEXT NOT NULL,
      career TEXT NOT NULL,
      hours INTEGER NOT NULL,
      enrolled TEXT NOT NULL,
      completed TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id TEXT NOT NULL,
      career TEXT NOT NULL,
      score INTEGER NOT NULL,
      status TEXT NOT NULL,
      findings TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  if (db.prepare('SELECT COUNT(*) AS count FROM courses').get().count === 0) {
    const stmt = db.prepare('INSERT INTO courses VALUES (?, ?, ?, ?, ?, ?)');
    for (const c of initialCourses) {
      stmt.run(c.code, c.title, c.credits, JSON.stringify(c.prerequisites), c.level, c.tag);
    }
  }

  if (db.prepare('SELECT COUNT(*) AS count FROM career_tracks').get().count === 0) {
    const stmt = db.prepare('INSERT INTO career_tracks VALUES (?, ?)');
    for (const [name, codes] of Object.entries(initialTracks)) {
      stmt.run(name, JSON.stringify(codes));
    }
  }
}

export function getAllCourses() {
  return db.prepare('SELECT * FROM courses ORDER BY code ASC').all().map((r) => ({
    ...r,
    prerequisites: JSON.parse(r.prerequisites),
  }));
}

export function getAllTracks() {
  const tracks = {};
  for (const r of db.prepare('SELECT * FROM career_tracks').all()) {
    tracks[r.name] = JSON.parse(r.course_codes);
  }
  return tracks;
}

export function saveStudentPlan(p) {
  db.prepare(`
    INSERT INTO student_plans VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(student_id) DO UPDATE SET
      name=excluded.name, branch=excluded.branch, semester=excluded.semester,
      experience=excluded.experience, career=excluded.career, hours=excluded.hours,
      enrolled=excluded.enrolled, completed=excluded.completed, updated_at=excluded.updated_at
  `).run(p.studentId, p.name, p.branch, p.semester, p.experience, p.career, p.hours, JSON.stringify(p.enrolled), JSON.stringify(p.completed), new Date().toISOString());
}

export function getStudentPlan(studentId) {
  const r = db.prepare('SELECT * FROM student_plans WHERE student_id = ?').get(studentId);
  if (!r) return null;
  return { studentId: r.student_id, name: r.name, branch: r.branch, semester: r.semester, experience: r.experience, career: r.career, hours: r.hours, enrolled: JSON.parse(r.enrolled), completed: JSON.parse(r.completed), updatedAt: r.updated_at };
}

export function saveAuditLog(studentId, career, report) {
  db.prepare('INSERT INTO audit_logs (student_id, career, score, status, findings, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(studentId, career, report.readinessScore, report.status, JSON.stringify(report.findings), new Date().toISOString());
}
