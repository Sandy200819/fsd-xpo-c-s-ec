﻿import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  initDatabase,
  getAllCourses,
  getAllTracks,
  saveStudentPlan,
  getStudentPlan,
  saveAuditLog,
} from './db.js';
import { AppError, generateRoadmap, runAdvisorAudit } from './services.js';
import {
  RoadmapRequestSchema,
  PlanRequestSchema,
  AuditRequestSchema,
  validateBody,
} from './validation.js';

initDatabase();

export const app = express();
app.use(cors());
app.use(express.json({ limit: '100kb' }));

function validateParamId(value, fieldName, maxLen = 64) {
  if (typeof value !== 'string' || value.trim().length === 0 || value.length > maxLen) {
    throw new AppError(`Invalid or missing field: '${fieldName}'`, 400);
  }
  return value.trim();
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'SkillSprout API', storage: 'SQLite' });
});

app.get('/api/courses', (_req, res) => {
  res.json(getAllCourses());
});

app.get('/api/tracks', (_req, res) => {
  res.json(getAllTracks());
});

app.post('/api/roadmap', validateBody(RoadmapRequestSchema), (req, res, next) => {
  try {
    const { career, experience } = req.validatedBody;
    const catalog = getAllCourses();
    const tracks = getAllTracks();
    const courses = generateRoadmap({ career, experience, catalog, tracks });

    res.json({
      career,
      experience,
      totalCredits: courses.reduce((s, c) => s + c.credits, 0),
      courses,
    });
  } catch (err) {
    next(err);
  }
});

app.get('/api/plans/:studentId', (req, res, next) => {
  try {
    const studentId = validateParamId(req.params.studentId, 'studentId', 64);
    const plan = getStudentPlan(studentId);
    if (!plan) {
      throw new AppError('Student plan not found.', 404);
    }
    res.json(plan);
  } catch (err) {
    next(err);
  }
});

app.put('/api/plans/:studentId', validateBody(PlanRequestSchema), (req, res, next) => {
  try {
    const studentId = validateParamId(req.params.studentId, 'studentId', 64);
    const { name, branch, semester, experience, career, hours, enrolled, completed } =
      req.validatedBody;

    saveStudentPlan({
      studentId,
      name,
      branch,
      semester,
      experience,
      career,
      hours,
      enrolled,
      completed,
    });
    res.json({ ok: true, savedAt: new Date().toISOString() });
  } catch (err) {
    next(err);
  }
});

app.post('/api/audit', validateBody(AuditRequestSchema), (req, res, next) => {
  try {
    const { studentId, career, hours, enrolled, completed } = req.validatedBody;
    const catalog = getAllCourses();
    const tracks = getAllTracks();
    const report = runAdvisorAudit({ career, hours, enrolled, completed, catalog, tracks });

    saveAuditLog(studentId, career, report);
    res.json(report);
  } catch (err) {
    next(err);
  }
});

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dist = path.resolve(__dirname, '../dist');
app.use(express.static(dist));
app.get('/{*splat}', (req, res, next) => {
  if (req.path.startsWith('/api/')) {
    return next(new AppError('API endpoint not found.', 404));
  }
  res.sendFile(path.join(dist, 'index.html'));
});

app.use((err, _req, res, _next) => {
  const status = err.statusCode || 500;
  res.status(status).json({
    error: err.message || 'Internal Server Error',
    details: err.details || undefined,
  });
});

const port = process.env.PORT || 4000;
if (process.env.NODE_ENV !== 'test') {
  app.listen(port, () => console.log(`SkillSprout API running at http://localhost:${port}`));
}
