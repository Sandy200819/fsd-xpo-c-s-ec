﻿import { z } from 'zod';
import { AppError } from './services.js';

const courseCodeSchema = z
  .string()
  .trim()
  .regex(/^[A-Z]{2,4}\d{3}$/, 'Must be a valid course code (e.g., CS101)');

const uniqueCourseArray = z
  .array(courseCodeSchema)
  .default([])
  .transform((arr) => [...new Set(arr)]);

export const RoadmapRequestSchema = z.object({
  career: z.string().trim().min(1).max(80).default('Full-Stack Web'),
  experience: z
    .enum(['New to coding', 'Some basics', 'Comfortable'])
    .default('New to coding'),
});

export const PlanRequestSchema = z.object({
  name: z.string().trim().max(60).optional().default('Student'),
  branch: z.string().trim().min(1).max(20).default('CSE'),
  semester: z.coerce.string().trim().min(1).max(5).default('1'),
  experience: z.string().trim().min(1).max(30).default('New to coding'),
  career: z.string().trim().min(1).max(50).default('Full-Stack Web'),
  hours: z.coerce.number().int().min(1).max(60),
  enrolled: uniqueCourseArray,
  completed: uniqueCourseArray,
});

export const AuditRequestSchema = z.object({
  studentId: z.string().trim().min(1).max(64).default('default-student'),
  career: z.string().trim().min(1).max(50).default('Full-Stack Web'),
  hours: z.coerce.number().min(1).max(60).default(10),
  enrolled: uniqueCourseArray,
  completed: uniqueCourseArray,
});

export function validateBody(schema) {
  return (req, _res, next) => {
    const result = schema.safeParse(req.body ?? {});
    if (!result.success) {
      const flattened = result.error.flatten();
      const firstMsg =
        Object.values(flattened.fieldErrors).flat()[0] || 'Invalid request payload';
      return next(new AppError(firstMsg, 400, flattened.fieldErrors));
    }
    req.validatedBody = result.data;
    next();
  };
}
