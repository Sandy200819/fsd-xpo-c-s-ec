﻿import test from 'node:test';
import assert from 'node:assert/strict';
import { RoadmapRequestSchema, AuditRequestSchema, PlanRequestSchema } from './validation.js';

test('Zod Validation: accepts valid roadmap career and experience fields', () => {
  const valid = RoadmapRequestSchema.safeParse({
    career: 'Full-Stack Web',
    experience: 'Some basics',
  });
  assert.equal(valid.success, true);
});

test('Zod Validation: rejects invalid course code formats in AuditRequestSchema', () => {
  const invalid = AuditRequestSchema.safeParse({
    studentId: 'MRVCSEC2630001',
    career: 'Full-Stack Web',
    hours: 15,
    enrolled: ['invalid_code'],
    completed: [],
  });
  assert.equal(invalid.success, false);
});

test('Zod Validation: validates student plan hours within 1-60 range', () => {
  const validPlan = PlanRequestSchema.safeParse({
    name: 'Student',
    branch: 'CSE',
    semester: '4',
    experience: 'Comfortable',
    career: 'Full-Stack Web',
    hours: 20,
    enrolled: ['CS101'],
    completed: [],
  });
  assert.equal(validPlan.success, true);
});
