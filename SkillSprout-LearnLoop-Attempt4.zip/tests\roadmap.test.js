﻿import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { resolveTopologicalOrder, generateRoadmap, runAdvisorAudit, AppError } from '../server/services.js';
import { courses, careerTracks } from '../server/data.js';

describe('Topological Sort & Prerequisite Resolution', () => {
  it('orders prerequisites strictly before dependent courses', () => {
    const ordered = resolveTopologicalOrder(['WD203', 'WD201', 'WD102', 'WD101', 'CS101', 'CS102', 'CS104'], courses);
    const codes = ordered.map((c) => c.code);
    assert.ok(codes.indexOf('CS101') < codes.indexOf('CS102'));
    assert.ok(codes.indexOf('WD101') < codes.indexOf('WD102'));
    assert.ok(codes.indexOf('WD102') < codes.indexOf('WD201'));
    assert.ok(codes.indexOf('WD201') < codes.indexOf('WD203'));
  });

  it('detects circular prerequisite dependencies and throws 409 Conflict', () => {
    const cyclicCatalog = [
      { code: 'A101', title: 'Course A', credits: 3, prerequisites: ['B101'], level: 'Beginner', tag: 'Test' },
      { code: 'B101', title: 'Course B', credits: 3, prerequisites: ['A101'], level: 'Beginner', tag: 'Test' },
    ];
    assert.throws(
      () => resolveTopologicalOrder(['A101', 'B101'], cyclicCatalog),
      (err) => err instanceof AppError && err.statusCode === 409
    );
  });

  it('automatically includes transitive prerequisites for beginners', () => {
    const roadmap = generateRoadmap({
      career: 'AI & Machine Learning',
      experience: 'New to coding',
      catalog: courses,
      tracks: careerTracks,
    });
    const codes = roadmap.map((c) => c.code);
    assert.ok(codes.includes('CS101'));
    assert.ok(codes.includes('MA101'));
    assert.ok(codes.indexOf('MA101') < codes.indexOf('MA102'));
  });
});

describe('Requirement 3.5: Academic Advisor Audit', () => {
  it('flags missing prerequisites when an advanced course is enrolled prematurely', () => {
    const report = runAdvisorAudit({
      career: 'Full-Stack Web',
      hours: 15,
      enrolled: ['WD201'],
      completed: [],
      catalog: courses,
      tracks: careerTracks,
    });
    assert.ok(report.readinessScore < 85);
    assert.ok(report.findings.some((f) => f.category === 'Prerequisite Violation'));
  });

  it('approves a valid, well-paced course plan', () => {
    const report = runAdvisorAudit({
      career: 'Full-Stack Web',
      hours: 20,
      enrolled: ['CS101', 'MA101', 'EN101', 'WD101'],
      completed: ['CS101'],
      catalog: courses,
      tracks: careerTracks,
    });
    assert.equal(report.findings.some((f) => f.severity === 'high'), false);
  });
});
