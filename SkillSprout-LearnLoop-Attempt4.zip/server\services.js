﻿export class AppError extends Error {
  constructor(message, statusCode = 400, details = null) {
    super(message);
    this.statusCode = statusCode;
    this.details = details;
  }
}

export function resolveTopologicalOrder(courseIds, catalog) {
  const courseMap = new Map(catalog.map((c) => [c.code, c]));
  const chosen = new Set(courseIds);
  const inDegree = new Map();
  const adjacency = new Map();

  for (const id of chosen) {
    if (!courseMap.has(id)) {
      throw new AppError(`Unknown course code: ${id}`, 404);
    }
    inDegree.set(id, 0);
    adjacency.set(id, []);
  }

  for (const id of chosen) {
    const course = courseMap.get(id);
    for (const prereq of course.prerequisites) {
      if (chosen.has(prereq)) {
        inDegree.set(id, inDegree.get(id) + 1);
        adjacency.get(prereq).push(id);
      }
    }
  }

  const queue = [...chosen].filter((id) => inDegree.get(id) === 0);
  const orderedIds = [];

  while (queue.length > 0) {
    const current = queue.shift();
    orderedIds.push(current);

    for (const neighbor of adjacency.get(current)) {
      inDegree.set(neighbor, inDegree.get(neighbor) - 1);
      if (inDegree.get(neighbor) === 0) {
        queue.push(neighbor);
      }
    }
  }

  if (orderedIds.length !== chosen.size) {
    throw new AppError(
      'Circular prerequisite dependency detected in course graph.',
      409,
      { unresolvedCourses: [...chosen].filter((id) => !orderedIds.includes(id)) }
    );
  }

  return orderedIds.map((id) => courseMap.get(id));
}

export function generateRoadmap({ career, experience, catalog, tracks }) {
  const selectedTrack = tracks[career];
  if (!selectedTrack) {
    throw new AppError(`Unsupported career track: ${career}`, 400);
  }

  const courseMap = new Map(catalog.map((c) => [c.code, c]));
  const requiredIds = new Set(selectedTrack);

  if (experience === 'New to coding') {
    ['CS101', 'MA101', 'EN101'].forEach((code) => {
      if (courseMap.has(code)) requiredIds.add(code);
    });
  }

  const collectPrerequisites = (code) => {
    const course = courseMap.get(code);
    if (!course) return;
    for (const prereq of course.prerequisites) {
      if (!requiredIds.has(prereq)) {
        requiredIds.add(prereq);
        collectPrerequisites(prereq);
      }
    }
  };

  [...requiredIds].forEach(collectPrerequisites);
  return resolveTopologicalOrder([...requiredIds], catalog);
}

export function runAdvisorAudit({ career, hours, enrolled, completed, catalog, tracks }) {
  const courseMap = new Map(catalog.map((c) => [c.code, c]));
  const enrolledSet = new Set(enrolled);
  const completedSet = new Set(completed);
  const trackCourses = tracks[career] || [];

  const findings = [];
  let deductions = 0;

  const missingPrereqs = [];
  for (const code of enrolled) {
    const course = courseMap.get(code);
    if (!course) continue;
    for (const prereq of course.prerequisites) {
      if (!completedSet.has(prereq) && !enrolledSet.has(prereq)) {
        missingPrereqs.push({ course: code, missingPrerequisite: prereq });
      }
    }
  }

  if (missingPrereqs.length > 0) {
    deductions += Math.min(35, missingPrereqs.length * 12);
    findings.push({
      severity: 'high',
      category: 'Prerequisite Violation',
      message: `${missingPrereqs.length} enrolled course(s) are missing required prerequisites.`,
      items: missingPrereqs.map((m) => `${m.course} requires ${m.missingPrerequisite}`),
    });
  } else {
    findings.push({
      severity: 'pass',
      category: 'Prerequisite Integrity',
      message: 'All enrolled courses satisfy prerequisite chain requirements.',
      items: [],
    });
  }

  const activeCourses = enrolled
    .filter((code) => !completedSet.has(code))
    .map((code) => courseMap.get(code))
    .filter(Boolean);

  const activeCredits = activeCourses.reduce((sum, c) => sum + c.credits, 0);
  const recommendedHours = Math.ceil(activeCredits * 1.2);

  if (activeCredits > 0 && hours < recommendedHours) {
    deductions += 20;
    findings.push({
      severity: 'medium',
      category: 'Workload Risk',
      message: `Active load is ${activeCredits} credits, which typically requires ~${recommendedHours} hrs/week (currently set to ${hours} hrs/week).`,
      items: ['Consider increasing weekly study hours or staging advanced courses across semesters.'],
    });
  } else {
    findings.push({
      severity: 'pass',
      category: 'Workload Balance',
      message: `Weekly study commitment (${hours} hrs) is well-aligned with your active credit load (${activeCredits} credits).`,
      items: [],
    });
  }

  const coveredTrackCourses = trackCourses.filter(
    (code) => enrolledSet.has(code) || completedSet.has(code)
  );
  const missingTrackCourses = trackCourses.filter(
    (code) => !enrolledSet.has(code) && !completedSet.has(code)
  );
  const trackCoveragePct = trackCourses.length
    ? Math.round((coveredTrackCourses.length / trackCourses.length) * 100)
    : 100;

  if (trackCoveragePct < 60) {
    deductions += 20;
    findings.push({
      severity: 'medium',
      category: 'Track Alignment Gap',
      message: `Your plan covers ${trackCoveragePct}% of core courses for ${career}.`,
      items: missingTrackCourses.slice(0, 5).map((code) => {
        const c = courseMap.get(code);
        return c ? `${c.code}: ${c.title}` : code;
      }),
    });
  } else {
    findings.push({
      severity: 'pass',
      category: 'Career Track Alignment',
      message: `Strong alignment (${trackCoveragePct}% coverage) with the ${career} track.`,
      items: [],
    });
  }

  let validSequence = [];
  if (enrolled.length > 0) {
    const ordered = resolveTopologicalOrder(enrolled, catalog);
    validSequence = ordered.map((c) => c.code);
  }

  const readinessScore = Math.max(0, 100 - deductions);
  const status =
    readinessScore >= 85
      ? 'Approved for Registration'
      : readinessScore >= 60
      ? 'Conditional Approval — Review Warnings'
      : 'Action Required — Fix Prerequisite & Load Issues';

  return {
    readinessScore,
    status,
    metrics: {
      activeCredits,
      recommendedHours,
      trackCoveragePct,
      enrolledCount: enrolled.length,
      completedCount: completed.length,
    },
    recommendedOrder: validSequence,
    findings,
  };
}
