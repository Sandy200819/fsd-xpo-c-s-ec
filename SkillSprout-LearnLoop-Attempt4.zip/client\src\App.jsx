﻿import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowUpRight,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  ClipboardCheck,
  Download,
  GitBranch,
  GraduationCap,
  LayoutDashboard,
  RotateCcw,
  Search,
  ShieldAlert,
  Sparkles,
  Users,
} from 'lucide-react';
import { courses as fallbackCourses, careerTracks as fallbackTracks } from './data';

const STORAGE_KEY = 'skillsprout-v2';
const DEFAULT_STUDENT = {
  studentId: 'MRVCSEC2630001',
  name: '',
  branch: 'CSE',
  semester: '1',
  experience: 'New to coding',
  career: 'Full-Stack Web',
  hours: 12,
  enrolled: [],
  completed: [],
  onboarded: false,
};

function loadInitialState() {
  try {
    return { ...DEFAULT_STUDENT, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') };
  } catch {
    return DEFAULT_STUDENT;
  }
}

function sortCoursesTopologically(ids, catalog) {
  const idSet = new Set(ids);
  const inDegree = {};
  const nextCourses = {};

  ids.forEach((id) => {
    inDegree[id] = 0;
    nextCourses[id] = [];
  });

  ids.forEach((id) => {
    const course = catalog.find((item) => item.code === id);
    (course?.prerequisites || [])
      .filter((prereq) => idSet.has(prereq))
      .forEach((prereq) => {
        inDegree[id] += 1;
        nextCourses[prereq].push(id);
      });
  });

  const queue = ids.filter((id) => inDegree[id] === 0);
  const ordered = [];

  while (queue.length > 0) {
    const current = queue.shift();
    ordered.push(current);
    nextCourses[current].forEach((neighbor) => {
      inDegree[neighbor] -= 1;
      if (inDegree[neighbor] === 0) queue.push(neighbor);
    });
  }

  return ordered.length === ids.length ? ordered : [];
}

function AdvisorAuditView({ student, onApplySequence }) {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const runAudit = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: student.studentId || student.name || 'default-student',
          career: student.career,
          hours: student.hours,
          enrolled: student.enrolled,
          completed: student.completed,
        }),
      });
      const data = await response.json();
      setReport(data);
    } catch {
      setReport({ error: 'Unable to reach Advisor Audit API. Start the backend server on port 4000.' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runAudit();
  }, [student.career, student.hours, student.enrolled.length, student.completed.length]);

  if (loading && !report) return <div className="card">Running Academic Advisor Audit...</div>;
  if (!report || report.error) return <div className="card">{report?.error || 'No audit report available.'}</div>;

  return (
    <section className="audit-grid">
      <div className="card audit-banner">
        <div>
          <span className="badge">{report.status}</span>
          <h2>Academic Readiness Score: {report.readinessScore}/100</h2>
          <p>
            Active Load: <strong>{report.metrics.activeCredits} credits</strong> · Recommended Study:{' '}
            <strong>{report.metrics.recommendedHours} hrs/week</strong> · Track Coverage:{' '}
            <strong>{report.metrics.trackCoveragePct}%</strong>
          </p>
        </div>
        <button className="secondary" onClick={runAudit}>
          Re-run Audit
        </button>
      </div>

      {report.findings.map((finding, idx) => (
        <div key={idx} className={`card audit-item severity-${finding.severity}`}>
          <div className="audit-title">
            {finding.severity === 'pass' ? <CheckCircle2 size={18} /> : <ShieldAlert size={18} />}
            <strong>{finding.category}</strong>
          </div>
          <p>{finding.message}</p>
          {finding.items?.length > 0 && (
            <ul className="audit-list">
              {finding.items.map((detail, i) => (
                <li key={i}>{detail}</li>
              ))}
            </ul>
          )}
        </div>
      ))}

      {report.recommendedOrder?.length > 0 && (
        <div className="card">
          <strong>Verified Topological Course Sequence:</strong>
          <p className="sequence-line">{report.recommendedOrder.join(' → ')}</p>
          <button className="secondary" onClick={() => onApplySequence(report.recommendedOrder)}>
            Apply Verified Order to Plan
          </button>
        </div>
      )}
    </section>
  );
}

export default function App() {
  const [student, setStudent] = useState(loadInitialState);
  const [catalog, setCatalog] = useState(fallbackCourses);
  const [tracks, setTracks] = useState(fallbackTracks);
  const [tab, setTab] = useState('Overview');
  const [query, setQuery] = useState('');
  const [levelFilter, setLevelFilter] = useState('All');
  const [toast, setToast] = useState('');
  const [syncStatus, setSyncStatus] = useState('Synced with SQLite');

  const notify = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2600);
  };

  useEffect(() => {
    Promise.all([fetch('/api/courses'), fetch('/api/tracks')])
      .then(async ([cRes, tRes]) => {
        if (cRes.ok) setCatalog(await cRes.json());
        if (tRes.ok) setTracks(await tRes.json());
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(student));
    if (!student.onboarded) return;

    fetch(`/api/plans/${encodeURIComponent(student.studentId || 'default-student')}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(student),
    })
      .then((res) => setSyncStatus(res.ok ? 'Saved to SQLite' : 'Saved locally'))
      .catch(() => setSyncStatus('Saved locally'));
  }, [student]);

  const activeTrack = tracks[student.career] || tracks['Full-Stack Web'] || [];

  const recommendedCourses = useMemo(() => {
    const ids = new Set([
      ...activeTrack,
      ...(student.experience === 'New to coding' ? ['CS101', 'MA101', 'EN101'] : []),
    ]);

    const addPrereqs = (code) => {
      const course = catalog.find((c) => c.code === code);
      (course?.prerequisites || []).forEach((prereq) => {
        if (!ids.has(prereq)) {
          ids.add(prereq);
          addPrereqs(prereq);
        }
      });
    };

    [...ids].forEach(addPrereqs);
    return sortCoursesTopologically([...ids], catalog)
      .map((code) => catalog.find((c) => c.code === code))
      .filter(Boolean);
  }, [activeTrack, student.experience, catalog]);

  const enrolledCourses = student.enrolled.map((code) => catalog.find((c) => c.code === code)).filter(Boolean);
  const completedCourses = enrolledCourses.filter((c) => student.completed.includes(c.code));
  const totalCredits = enrolledCourses.reduce((sum, c) => sum + c.credits, 0);
  const doneCredits = completedCourses.reduce((sum, c) => sum + c.credits, 0);
  const progressPct = enrolledCourses.length ? Math.round((completedCourses.length / enrolledCourses.length) * 100) : 0;

  const isReadyToEnroll = (course) =>
    course.prerequisites.every((prereq) => student.completed.includes(prereq) || student.enrolled.includes(prereq));

  const enrollCourse = (course) => {
    if (!isReadyToEnroll(course)) {
      notify('Complete or enroll in required prerequisites first.');
      return;
    }
    setStudent((prev) => ({ ...prev, enrolled: [...new Set([...prev.enrolled, course.code])] }));
    notify(`${course.code} added to your plan`);
  };

  const toggleCompleted = (course) => {
    if (!student.enrolled.includes(course.code)) {
      enrollCourse(course);
      return;
    }
    setStudent((prev) => ({
      ...prev,
      completed: prev.completed.includes(course.code)
        ? prev.completed.filter((code) => code !== course.code)
        : [...prev.completed, course.code],
    }));
  };

  const filteredCatalog = catalog.filter(
    (c) => `${c.code} ${c.title} ${c.tag}`.toLowerCase().includes(query.toLowerCase()) && (levelFilter === 'All' || c.level === levelFilter)
  );

  const navItems = [
    ['Overview', LayoutDashboard],
    ['My Roadmap', GitBranch],
    ['Course Catalog', BookOpen],
    ['Advisor Audit', ClipboardCheck],
    ['Study Groups', Users],
  ];

  if (!student.onboarded) {
    return (
      <main className="welcome">
        <div className="welcome-card">
          <div className="brand">
            <span className="brand-icon"><GraduationCap /></span> SkillSprout <span className="tagline">LEARNLOOP</span>
          </div>
          <div className="eyebrow"><Sparkles size={15} /> YOUR LEARNING, WITH A PLAN</div>
          <h1>Grow skills.<br /><em>Find your direction.</em></h1>
          <form onSubmit={(e) => { e.preventDefault(); setStudent((v) => ({ ...v, onboarded: true })); }} className="intake">
            <label>
              Your name
              <input value={student.name} onChange={(e) => setStudent((v) => ({ ...v, name: e.target.value }))} placeholder="e.g. Alex" />
            </label>
            <div className="form-grid">
              <label>
                Branch
                <select value={student.branch} onChange={(e) => setStudent((v) => ({ ...v, branch: e.target.value }))}>
                  {['CSE', 'IT', 'ECE', 'EEE', 'Mechanical', 'Civil', 'Other'].map((b) => <option key={b}>{b}</option>)}
                </select>
              </label>
              <label>
                Semester
                <select value={student.semester} onChange={(e) => setStudent((v) => ({ ...v, semester: e.target.value }))}>
                  {Array.from({ length: 8 }, (_, i) => <option key={i + 1} value={i + 1}>{i + 1}</option>)}
                </select>
              </label>
              <label>
                Experience
                <select value={student.experience} onChange={(e) => setStudent((v) => ({ ...v, experience: e.target.value }))}>
                  {['New to coding', 'Some basics', 'Comfortable'].map((exp) => <option key={exp}>{exp}</option>)}
                </select>
              </label>
              <label>
                Career direction
                <select value={student.career} onChange={(e) => setStudent((v) => ({ ...v, career: e.target.value }))}>
                  {Object.keys(tracks).map((tr) => <option key={tr}>{tr}</option>)}
                </select>
              </label>
            </div>
            <label>
              Weekly study hours <strong>{student.hours} hrs</strong>
              <input type="range" min="2" max="35" value={student.hours} onChange={(e) => setStudent((v) => ({ ...v, hours: Number(e.target.value) }))} />
            </label>
            <button className="primary wide">Build my roadmap <ChevronRight size={18} /></button>
          </form>
        </div>
      </main>
    );
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-icon"><GraduationCap /></span> SkillSprout</div>
        <div className="workspace">LEARNING WORKSPACE</div>
        <nav>
          {navItems.map(([label, Icon]) => (
            <button key={label} className={tab === label ? 'active' : ''} onClick={() => setTab(label)}>
              <Icon size={18} /> {label}
            </button>
          ))}
        </nav>
        <div className="side-bottom">
          <div className="avatar">{(student.name || 'S')[0].toUpperCase()}</div>
          <div>
            <b>{student.name || 'Student'}</b>
            <small>{student.branch} · Semester {student.semester}</small>
          </div>
          <button className="icon-btn" title="Edit profile" onClick={() => setStudent((v) => ({ ...v, onboarded: false }))}>
            <RotateCcw size={16} />
          </button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div><span className="crumb">Workspace</span> <ChevronRight size={14} /> <b>{tab}</b></div>
          <div className="top-right"><span className="status"><span /> {syncStatus}</span></div>
        </header>

        <div className="content">
          <div className="page-head">
            <div>
              <h1>{tab === 'Overview' ? `Welcome back${student.name ? ', ' + student.name.split(' ')[0] : ''}.` : tab}</h1>
              <p>Track: {student.career} · Progress: {progressPct}% ({doneCredits}/{totalCredits} credits)</p>
            </div>
            <button className="secondary" onClick={() => window.print()}><Download size={16} /> Print / PDF</button>
          </div>

          {tab === 'Overview' && (
            <section className="hero">
              <div>
                <div className="hero-label"><Sparkles size={15} /> PERSONAL LEARNING PATH</div>
                <h2>{student.career}</h2>
                <p>Recommended sequence of {recommendedCourses.length} courses ordered via Kahn's DAG topological sort.</p>
                <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1rem' }}>
                  <button className="hero-btn" onClick={() => setTab('My Roadmap')}>View Roadmap <ArrowUpRight size={17} /></button>
                  <button className="secondary" onClick={() => setTab('Advisor Audit')}>Run Advisor Audit</button>
                </div>
              </div>
            </section>
          )}

          {tab === 'My Roadmap' && (
            <section className="course-grid">
              {recommendedCourses.map((course, idx) => {
                const isEnrolled = student.enrolled.includes(course.code);
                const isDone = student.completed.includes(course.code);
                return (
                  <div key={course.code} className="card">
                    <small>Step {idx + 1} · {course.code} · {course.credits} Credits</small>
                    <h3>{course.title}</h3>
                    <p>Prerequisites: {course.prerequisites.join(', ') || 'None'}</p>
                    <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.75rem' }}>
                      <button className="secondary" onClick={() => enrollCourse(course)}>{isEnrolled ? 'Enrolled' : 'Add to Plan'}</button>
                      <button className="secondary" onClick={() => toggleCompleted(course)}>{isDone ? 'Completed ✓' : 'Mark Done'}</button>
                    </div>
                  </div>
                );
              })}
            </section>
          )}

          {tab === 'Course Catalog' && (
            <section>
              <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1rem' }}>
                <div className="search-box">
                  <Search size={16} />
                  <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search code, title, or tag..." />
                </div>
                <select value={levelFilter} onChange={(e) => setLevelFilter(e.target.value)}>
                  {['All', 'Beginner', 'Intermediate', 'Advanced'].map((lvl) => <option key={lvl}>{lvl}</option>)}
                </select>
              </div>
              <div className="course-grid">
                {filteredCatalog.map((course) => (
                  <div key={course.code} className="card">
                    <small>{course.code} · {course.level} · {course.credits} Credits</small>
                    <h3>{course.title}</h3>
                    <p>Prerequisites: {course.prerequisites.join(', ') || 'None'}</p>
                    <button className="secondary" onClick={() => enrollCourse(course)}>
                      {student.enrolled.includes(course.code) ? 'In Plan' : 'Enroll'}
                    </button>
                  </div>
                ))}
              </div>
            </section>
          )}

          {tab === 'Advisor Audit' && (
            <AdvisorAuditView
              student={student}
              onApplySequence={(orderedCodes) => {
                setStudent((prev) => ({ ...prev, enrolled: orderedCodes }));
                notify('Applied verified topological order to your plan.');
              }}
            />
          )}

          {tab === 'Study Groups' && (
            <section className="card">
              <h3>{student.career} Peer Cohort</h3>
              <p>Connect with {student.branch} Semester {student.semester} peers studying {enrolledCourses.map((c) => c.code).join(', ') || 'core foundations'}.</p>
            </section>
          )}
        </div>
      </main>

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
