﻿# SkillSprout — LearnLoop

An academic roadmap planner and prerequisite verification engine powered by Kahn's Topological Sort (DAG), SQLite persistence, and an automated Academic Advisor Audit module.

## Architecture & Engineering Highlights
- **Persistent SQLite Storage (`server/db.js`)**: Stores courses, career tracks, student enrollment plans (`PUT /api/plans/:studentId`), and historical advisor audit logs (`POST /api/audit`).
- **Modular Service Layer (`server/services.js`)**: Separates DAG topological sorting, cycle detection (`409 Conflict`), and Requirement 3.5 Advisor Audit rules from HTTP routing.
- **Schema Validation & Error Handling (`server/validation.js`, `server/index.js`)**: Enforces Zod payload schemas and course code formats (`^[A-Z]{2,4}\d{3}$`), returning structured HTTP status codes (`400`, `404`, `409`).
- **Automated Test Suite (`tests/`, `server/validation.test.js`)**: Unit, validation, and REST API integration tests using Node's native test runner (`node --test`).

## Running Locally
1. Install dependencies: `npm install`
2. Run automated unit & integration tests: `node --test tests/*.test.js server/*.test.js`
3. Build frontend assets: `npm run build`
4. Start the full-stack server: `node server/index.js`
